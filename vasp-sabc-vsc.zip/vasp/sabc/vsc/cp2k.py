#!/usr/bin/env python
import os
def outEnergy():
    b = os.popen('''awk '/ENERGY\|/{print $9}' out.cp2k | tail -1''').read()
    try:
        e = float(b)
        e = e * 27.2113845 
    except:
        e = 610612509
    return e
if __name__ == '__main__':
    e = outEnergy()
    print(e)
