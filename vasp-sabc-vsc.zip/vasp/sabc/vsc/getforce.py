#!/usr/bin/env python
#f=open('OUTCAR_F','r')
#force=[]
#sign_F=0
#num1=0
#num2=0
#print 'Forces1'
#for line in f:
#    if 'TOTAL-FORCE (eV/Angst)' in line: num1+=1
#f.close()
#f=open('OUTCAR_F','r')
#for line in f:
#    if 'TOTAL-FORCE (eV/Angst)' in line: num2+=1
#    if num2==num1:
#        if '---------' in line: continue
#        if 'total drift' in line :
#            sign_F=0
#            print'%10.6f %10.6f %10.6f' % tuple(map(float,line.strip().split()[2:5]))
#        if sign_F==-1:
#            print'%10.6f %10.6f %10.6f' % tuple(map(float,line.strip().split()[3:6]))
#        if 'TOTAL-FORCE (eV/Angst)' in line: sign_F=-1
#        if 'total drift' in line :sign_F=0
#f.close()
f=open('OUTCAR','r')
force=[]
sign_F=0
num1=0
num2=0
print('Forces2')
for line in f:
    if 'TOTAL-FORCE (eV/Angst)' in line: num1+=1
f.close()
f=open('OUTCAR','r')
for line in f:
    if 'TOTAL-FORCE (eV/Angst)' in line: num2+=1
    if num2==num1:
        if '---------' in line: continue
        if 'total drift' in line :
            sign_F=0
         #   print'%10.6f %10.6f %10.6f' % tuple(map(float,line.strip().split()[2:5]))
        if sign_F==-1:
            print('%10.6f %10.6f %10.6f' % tuple(map(float,line.strip().split()[3:6])))
        if 'TOTAL-FORCE (eV/Angst)' in line: sign_F=-1
        if 'total drift' in line :sign_F=0
f.close()
#f=open('OUTCAR','r')
#for line in f:
#    if 'in kB' in line :
#    	kB=filter(lambda ch:ch in'-. 0123456789',line).strip()
#f.close()
#print 'stress'
#print kB
