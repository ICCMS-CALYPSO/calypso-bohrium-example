#!/usr/bin/env python
import os
import sys
import math
import string
def prec():
    global args
    args = sys.argv
    global numatom
    global namele
    global num_nam
    if os.path.exists('input.dat'):
        dinput='input.dat'
    d=open(dinput,'r')
    ddata = {}
    for line in d:
        if '=' in line:
            litem=line.split('=')
            ddata[litem[0].strip()]=litem[1].strip()
    d.close()
    numatom=[]
    numatom_sub = ddata['NumberOfAtoms']
    numformu = ddata['NumberOfFormula'].split()
    namele = ddata['NameOfAtoms'].split()
    def formu_natom(x):return '_'.join(str(int(x)*int(numformu[0])))
    for i in range(0,len(numatom_sub.strip().split())):
        numatom+=list(map(formu_natom,numatom_sub.strip().split()[i]))
   # print '_'.join(numatom)
    num_nam={}
    number_count=0
    for i in range(0,len(namele)):
        for j in range(0,int(numatom[i][0])):
            num_nam[str(number_count)]=namele[i]
            number_count+=1
def readinput():
    if os.path.exists('out.pw'):
        finput = 'out.pw'
    else:
        exit()
    
    f=open(finput,'r')
    indata = {}
    for line in f:
        if '=' in line:
            litem=line.split('=')
            indata[litem[0].strip()]=litem[1].strip()
    f.close()
    totalenergy = indata['!    total energy'].split()
    f=open(finput,'r')
    a=0
    b=0
    aa=[]
    for line in f:
        if a>=1 and a<=3 :
            aa.append(line.strip())
            a+=1
        if 'CELL_PARAMETERS' in line: 
            a=1
        if b==1 :
            if len(line)<=1:
                b=0
                continue
            # bb.append('  '.join(list(map(float,(line.split()[1:])))))
            if 'final' not in line:
                bb.append('  '.join(line.split()[1:]) )
                # bb.remove('final  coordinates') if 'final  coordinates' in bb else ''
                num+=1
        if 'ATOMIC_POSITIONS' in line:
            b=1
            bb=[]
            num=0
    f.close()
    cc=[]
    aaa=[]
    for i in range(-1,-num-1,-1):
        if len(bb[i])>=1:
            cc.append(bb[i])
    cc.reverse()
    if (args)==1 : 
        def au(x):return x*0.529177
    else:
        def au(x): return x
    for i in range(-3,0):
        aaa.append(aa[i].split())
    tmp=[]
    for line in aaa:
        tmp.append(list(map(float,line)))
    int(tmp[0][0])
    int(cc[0][-1])
    if len(args)==1 : print(totalenergy[0])
    print('CELL_PARAMETERS')
    if len(args)==1 : print('1.00000000')
    for line in tmp:
        print('%10.7f %10.7f %10.7f' % tuple((list(map(au,line)))))
    if len(args)==1 : 
	#for i in range(0,len(namele)):
	    print(' '.join(numatom))
    print('ATOMIC_POSITIONS crystal')
    if len(args)==1 :
        for line in cc:
            print(line)
    else :
        j=0
        for line in cc:
                print(num_nam[str(j)],line)
                j+=1
def elseother():
    if len(args)==1: print('610612509')
    if os.path.exists('pwscf.bak'):
        pw='pwscf.bak'
        pwscf=open(pw,'r')
    b=0
    x=0
    xx=0
    for line in pwscf:
        if 'K_POINTS' in line: sys.exit(0)
        if x==1: xx+=1
        if b==1:
            if len(args)==1: 
                # print([ch for ch in line if ch in' -0123456789.'].strip())
                print('  '.join(line.split()[1:]))
            else:
                print(line.strip())
        else:
            print(line.strip())
        if 'ATOMIC_POSITIONS' in line :
            b=1
        if 'CELL_PARAMETERS' in line:
            if len(args)==1: print('1.0000000')
            x=1
        if xx==3 and len(args)==1: print(' '.join(numatom))
    pwscf.close()    
if __name__ == '__main__' :
    prec()
    try: 
        readinput()
    except:
        elseother()
