#!/usr/bin/env python
# -*- coding: utf-8 -*-
# This is a part of calypso code.
# author : Li Zhu < zl@calypso.cn >
import sys
import os
def gpid(fpid):
    allpid = []
    allpid.append(fpid)
    b = os.popen('ps --ppid ' + fpid).read().split('\n')
    while len(b) == 3:
        spid = b[1].split()[0]
        allpid.append(spid)
        b = os.popen('ps --ppid ' + spid).read().split('\n')
    return ' '.join(allpid)
    
if __name__ == '__main__':
    fpid = sys.argv[1]
    os.system('kill -9 ' + gpid(fpid) + '  2 > /dev/null')
