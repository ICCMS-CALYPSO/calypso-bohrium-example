#!/usr/bin/env python
import os
import sys
import numpy as np
def v2lammps(poscar):
    try:
        f = open(poscar)
    except:
        print('Open ' + poscar + 'error')
        sys.exit(0)
    aa = []
    try:
        for line in f:
            aa.append(line.split())
    finally:
        f.close()
    lat = np.array(aa[2:5], float)
    try:
        typt = list(map(int, aa[5]))
    except:
        del(aa[5])
        typt = list(map(int, aa[5]))
    print(typt)
    natom = sum(typt)
    nele = len(typt)
    atoms = np.array( aa[7 : 7+natom], float )
    atomsc = np.dot(atoms, lat)
    typp = []
    for i in range(nele):
        typp += [i+1]*typt[i]
 
    f = open('data.lammps', 'w')
    f.write('lammps\n')
    f.write(str(natom) + '  atoms\n')
    f.write(str(nele) + ' atom types\n')
    f.write('%12.6f %12.6f  xlo xhi\n' % (0.0, lat[0][0]))
    f.write('%12.6f %12.6f  ylo yhi\n' % (0.0, lat[1][1]))
    f.write('%12.6f %12.6f  zlo zhi\n' % (0.0, lat[2][2]))
    f.write('%12.6f %12.6f %12.6f xy xz yz\n' % (lat[1][0], lat[2][0], lat[2][1]))
    f.write('Atoms\n\n')
    for i in range(natom):
        f.write('%6d %6d ' % (i+1, typp[i]))
        f.write('%15.8f %15.8f %15.8f \n' % tuple(atomsc[i]))
    f.close()
if __name__ == '__main__':
    if len(sys.argv) > 1:
        poscar = sys.argv[1]
    else:
        poscar = 'CONTCAR'
    v2lammps(poscar)
