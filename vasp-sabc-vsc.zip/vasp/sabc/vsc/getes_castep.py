#!/usr/bin/env python
import os
def outEnergy():
    
    natom = get_natom()
    
    b = os.popen('''awk '/with enthalpy/{print $7}' castep.castep | tail -1''').read()
    try:
        e = float(b) / natom
    except:
        e = 610612509
    return e
    
def get_natom():
    f = open('CONTCAR')
    b = []
    try:
        for line in f:
            b.append(line.split())
    finally:
        f.close()
        
    natom = sum(map(int, b[5]))
    return natom
if __name__ == '__main__':
    e = outEnergy() 
    print(e)
