#!/usr/bin/env python
# file: pos2find.py 
import sys
import os
def pos2find(poscar):
    num_atom = list(map(int, poscar[5].split()))
    total_num_atom = sum(num_atom)
    num_ele = len(num_atom)
    global prec
    fd = open('abc.tmp', 'w')
    print('pos2findsym', file=fd)
    print(prec, file=fd)
    print(1, file=fd)
    for i in range(2, 5):
        print(poscar[i], end=' ', file=fd)
    print(1, file=fd)
    print('1 0 0', file=fd)
    print('0 1 0', file=fd)
    print('0 0 1', file=fd)
    print(total_num_atom, file=fd)
    for i in range(0, num_ele):
        print((str(i+1)+' ')*(num_atom[i]), end=' ', file=fd)
    print(file=fd)
    for i in range(7, 7+total_num_atom):
        print(poscar[i], end=' ', file=fd)
    fd.close()
args = sys.argv
if len(args)==1:
    pos = 'POSCAR'
    mm = 5
elif len(args)==2:
    try:
        mm=int(args[1])
        pos = 'POSCAR'
    except:
        mm = 5
        pos = args[1]
else:
    pos = args[1]
    mm = int(args[2])
if mm == 1:
    prec = '1.0e-01'
elif mm == 2:
    prec = '1.0e-02'
elif mm == 3:
    prec = '1.0e-03'
elif mm == 4:
    prec = '1.0e-04'
elif mm == 5:
    prec = '1.0e-05'
else:
    prec = '1.0e-05'
poscar = []
f = open(pos)
try:
    for line in f:
        poscar.append(line)
finally:
    f.close()
pos2find(poscar)
os.system('findsym < abc.tmp')
os.system('rm -f abc.tmp')
