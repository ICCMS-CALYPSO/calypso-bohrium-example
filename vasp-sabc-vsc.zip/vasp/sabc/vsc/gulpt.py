#!/usr/bin/env python
# Version: 20110706
import os
from fractions import Fraction
def gete():
    ee = os.popen('''awk '/totalenergy/{print $2}' gulpopt''').read()
    try:
        e = float(ee)/(len(a)-4)
    except:
        e = 610612509
    print(e)
    return e
def getopt():
    v = True
    f = open('gulpoutput')
    global a
    a = []
    try:
        for line in f:
            a.append(line)
    finally:
        f.close()
    aa = [item.split() for item in a]
    try:
        ll = list(map(float, aa[2][0:5]))
    except:
        a[2] = '  1.0  1.0  1.0  90.0  90.0  90.0\n'
        v = False
    for i in range(4, len(aa)):
        try:
            b = list(map(float, [Fraction(ipp) for ipp in aa[i][2:5]]))
            bb = aa[i][0]+'    '+aa[i][1]+'  '+str(b[0])+' '+str(b[1])+' '+str(b[2])+' 0.00000000 1.00000 0.00000\n'
            a[i] = bb
        except:
            bb = aa[i][0]+'    '+aa[i][1]+' 1.0 1.0 1.0 0.0 1.0 0.0\n'
            a[i] = bb
            v = False
    f = open('gulpoutput', 'w')
    for item in a:
        f.write(item)
    f.close()
    return v
def run():
    v = getopt()
    if v:
        gete()
    else:
        print(610612509)
if __name__ == '__main__':
    run()
