#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Author : Li Zhu < zl@calypso.cn >
import os
def get_natom():
    f = open('relax.lammpstrj')
    datas = []
    try:
        for line in f:
            datas.append(line.split())
    finally:
        f.close()
    natom = int(datas[3][0])
    return natom
def outEnergy():
    natom = get_natom()
    b = os.popen('''grep Enthalpy log.lammps | tail -1''').read().split('=')[1]
    try:
        e = float(b) / natom
    except:
        e = 610612509
        
    return e
def get_press():
    b = os.popen('''grep Pressure log.lammps | tail -1 ''').read().split('=')[1]
    try:
        p = float(b)
        if abs(p) < 5e5:
            return True
        else:
            return False
    except:
        return False
    
if __name__ == '__main__':
    try:
        if get_press():
            e = outEnergy()
        else:
            e = 610612509
    except:
        e = 610612509
    print(e)
